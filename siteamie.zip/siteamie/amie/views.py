from django.shortcuts import render
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.conf import settings
from django.views.decorators.csrf import requires_csrf_token

def index(request):
    return render(request, 'amie/index.html')
def about(request):
    return render(request, 'amie/about.html')
# Create your views here.
def create(request):
    return render(request,'amie/create.html')
